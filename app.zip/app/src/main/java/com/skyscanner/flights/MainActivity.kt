package com.skyscanner.flights.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FlightsUI()
        }
    }
}

@Composable
fun FlightsUI() {
    var passengerCount by remember { mutableStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Flight Itinerary",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(0.dp, 0.dp, 0.dp, 20.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("✈ From: Hyderabad")
                Text("🏁 To: Bangalore")
                Text("🗓 Date: 30 Nov 2025")
                Text("⏰ Time: 6:45 AM")
                Text("🛫 Airline: Indigo")
                Text("💺 Seat: 12A")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Passengers: $passengerCount", fontSize = 18.sp)

        Button(onClick = { passengerCount++ }) {
            Text("+ Add Passenger")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewUI() {
    FlightsUI()
}
